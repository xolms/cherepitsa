@extends('layouts.error')
@section('meta')
    <title>Страница не найдена</title>
@endsection

@section('content')
   <div class="head-title">
	<div class="container">
		<div class="row">
			<h2 class="page-title">Страница не найдена</h2>
		</div><!-- end row -->
	</div><!-- end container -->
    </div>
@endsection