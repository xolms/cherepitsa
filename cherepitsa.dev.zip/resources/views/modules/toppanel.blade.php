

<div class="top-panel invert">
    <div class="top-panel__container container">
        <div class="top-panel__top">
            <div class="top-panel__left">
                <div class="contact-block contact-block--header">
                    <div class="contact-block__inner">
                        <div class="contact-block__item contact-block__item--icon">
                            <i class="contact-block__icon linearicon linearicon-map-marker"></i>
                            <div class="contact-block__value-wrap"><span class="contact-block__label">Адрес:</span><span class="contact-block__text">{{$setting['adres']}}</span></div>
                        </div>
                        <div class="contact-block__item contact-block__item--icon">
                            <i class="contact-block__icon linearicon linearicon-telephone"></i>
                            <div class="contact-block__value-wrap"><span class="contact-block__label">Телефон:</span><span class="contact-block__text"><a href="tel:{{$setting['telefon']}}">{{$setting['telefon']}}</a>; <a href="tel:{{$setting['dopolnitel-nyy-telefon']}}">{{$setting['dopolnitel-nyy-telefon']}}</a></span></div>
                        </div>
                        <div class="contact-block__item contact-block__item--icon">
                            <i class="contact-block__icon linearicon linearicon-clock"></i>
                            <div class="contact-block__value-wrap"><span class="contact-block__label">Часы работы:</span><span class="contact-block__text">{{$setting['chasy-raboty']}}</span></div>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </div>
</div>
<!-- .top-panel -->

