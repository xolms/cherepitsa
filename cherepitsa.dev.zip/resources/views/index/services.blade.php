<section class="home-service">
    <div class="container">
        <div class="row">

            <div class="col-service">
						<span class="small-icon">
							<i class="fa fa-fw fa-group"></i>
						</span>
                <div class="small-icon-text">
                    <h4>Professional Team</h4>
                    <p>Claritas est etiam processus dynamic, qui sequitur mutationem consetudium lectorum.</p>
                </div><!-- end text -->
            </div><!-- end column -->

            <div class="col-service">
						<span class="small-icon">
							<i class="fa fa-fw fa-gears"></i>
						</span>
                <div class="small-icon-text">
                    <h4>Operation &amp; Maintenance</h4>
                    <p>Claritas est etiam processus dynamic, qui sequitur mutationem consetudium lectorum.</p>
                </div><!-- end text -->
            </div><!-- end column -->

            <div class="col-service">
						<span class="small-icon">
							<i class="fa fa-fw fa-clipboard"></i>
						</span>
                <div class="small-icon-text">
                    <h4>Project Control</h4>
                    <p>Claritas est etiam processus dynamic, qui sequitur mutationem consetudium lectorum.</p>
                </div><!-- end text -->
            </div><!-- end column -->

        </div><!-- end row -->
    </div><!-- end container -->
</section><!-- end service-row -->